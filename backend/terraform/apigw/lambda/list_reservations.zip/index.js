"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = process.env.DYNAMODB_TABLE;
const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Content-Type': 'application/json'
};
const handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    // Handle OPTIONS for CORS preflight
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: ''
        };
    }
    try {
        // Estrai l'ID utente Cognito dal token (sub claim)
        const authenticatedUserId = event.requestContext?.authorizer?.claims?.sub;
        if (!authenticatedUserId) {
            return {
                statusCode: 401,
                headers: corsHeaders,
                body: JSON.stringify({ message: 'Utente non autenticato', code: 'UNAUTHORIZED' })
            };
        }
        // Parametri query string
        const queryParams = event.queryStringParameters || {};
        // Se userId viene passato, usalo (altrimenti usa l'utente autenticato)
        const targetUserId = queryParams.userId || authenticatedUserId;
        const statusFilter = queryParams.status;
        const dateFilter = queryParams.date;
        console.log('Query params:', { targetUserId, statusFilter, dateFilter });
        // Query per PK (userId)
        const queryCommand = {
            TableName: TABLE_NAME,
            KeyConditionExpression: 'PK = :pk AND begins_with(SK, :sk)',
            ExpressionAttributeValues: {
                ':pk': `USER#${targetUserId}`,
                ':sk': 'RESERVATION#'
            }
        };
        // Aggiungi filtri opzionali
        const filterExpressions = [];
        if (statusFilter) {
            filterExpressions.push('#status = :status');
            queryCommand.ExpressionAttributeValues[':status'] = statusFilter;
            queryCommand.ExpressionAttributeNames = queryCommand.ExpressionAttributeNames || {};
            queryCommand.ExpressionAttributeNames['#status'] = 'status';
        }
        if (dateFilter) {
            filterExpressions.push('#date = :date');
            queryCommand.ExpressionAttributeValues[':date'] = dateFilter;
            queryCommand.ExpressionAttributeNames = queryCommand.ExpressionAttributeNames || {};
            queryCommand.ExpressionAttributeNames['#date'] = 'date';
        }
        if (filterExpressions.length > 0) {
            queryCommand.FilterExpression = filterExpressions.join(' AND ');
        }
        console.log('DynamoDB Query:', JSON.stringify(queryCommand, null, 2));
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand(queryCommand));
        console.log(`Trovate ${result.Items?.length || 0} prenotazioni`);
        // Mappa i risultati nel formato atteso dal frontend
        const reservations = (result.Items || []).map(item => ({
            id: item.id,
            userId: item.userId,
            date: item.date,
            time: item.time,
            category: item.category,
            doctor: item.doctor,
            status: item.status,
            location: item.location || null,
            createdAt: item.createdAt
        }));
        // Ordina per data (più recenti prima)
        reservations.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify(reservations)
        };
    }
    catch (error) {
        console.error('Errore:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({
                message: 'Errore interno del server',
                code: 'INTERNAL_ERROR'
            })
        };
    }
};
exports.handler = handler;
